<?php

use PrestaShop\PrestaShop\Core\Domain\Webservice\ValueObject\Key;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;


class MyModule extends Module implements WidgetInterface

{
    public function renderWidget($hookName = null, array $configuration = []){
        return $this->display(__FILE__, 'views/templates/widget/test.tpl');
    }
    public function getWidgetVariables($hookName = null, array $configuration = []){
        return [
            'test' => 'tst'
        ];
    } 
    public function __construct()
    {
        $this->name = 'mymodule';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Firstname Lastname';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.7.2.0',
            'max' => _PS_VERSION_ 
        ];
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('My module');
        $this->description = $this->l('Description of my module.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        if (!Configuration::get('MYMODULE_NAME')) {
            $this->warning = $this->l('No name provided');
        }
        $this->registerHook('displayHeader');
    }
  
    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
     
        if (!parent::install() ||
            !$this->registerHook('leftColumn') ||
            !$this->registerHook('header') ||
            !$this->registerHook('displayHeader') ||
            !Configuration::updateValue('MYMODULE_PAGENAME', 'Mentions légales')
        ) {
            return false;
        }
     
        return true;
    }

    public function hookLeftColumn($params) {

    }

    public function hookDisplayHome($params) {
         return $this->display(__FILE__, 'views/templates/hook/allproducts.tpl');
          /*$this->display(__FILE__, 'views/templates/hook/table.tpl');
          $this->display(__FILE__, 'views/templates/hook/lighting.tpl');
          $this->display(__FILE__, 'views/templates/hook/seating.tpl');
          $this->display(__FILE__, 'views/templates/hook/storage.tpl');
          $this->display(__FILE__, 'views/templates/hook/culinary.tpl');
          $this->display(__FILE__, 'views/templates/hook/decoration.tpl');*/
    }

    public function hookHeader($params) {
      $this->context->controller->addCSS($this->_path . 'views/css/mymodule.css', array('media' => 'all', 'priority' => 150));
      $this->context->controller->addJS($this->_path . 'views/js/mymodule.js', array('media' => 'all', 'priority' => 150));

      Media::addJsDef(array(
        'MYMODULE_SPEED' => Configuration::get('MYMODULE_SPEED')
      ));
    }

    public function hookDisplayHeader($params) {
        $this->hookHeader($params);
    }

    public function hookActionAdminControllerSetMedia() {

    }

    public function hookDisplayDashboardTop() {

    }

    public function uninstall()
    {
        if (!parent::uninstall() ||
            !Configuration::deleteByName('MYMODULE_NAME')
        ) {
            return false;
        }

        // Storing a serialized array.
        Configuration::updateValue('MYMODULE_SETTINGS', serialize(array(true, true, false)));
        // Retrieving the array.
        $configuration_array = unserialize(Configuration::get('MYMODULE_SETTINGS'));
        return true;
    }

    public function getContent()
    {
       $output = null;
       if (Tools::isSubmit('submit' . $this->name)) {
           $speed = Tools::getValue('MYMODULE_SPEED');
           $rows = Tools::getValue('MYMODULE_ROWS');
           $products = Tools::getValue('MYMODULE_PRODUCT');

           if (!$speed || empty($speed) || !Validate::isGenericName($speed)) {
               $output .= $this->displayError($this->l('Configuration failed'));
           } else {
               Configuration::updateValue('MYMODULE_SPEED', $speed);
               Configuration::updateValue('MYMODULE_ROWS', $rows);
               Configuration::updateValue('MYMODULE_PRODUCT', $products);
               $output .= $this->displayConfirmation($this->l('Update successful'));
           }
       }
       return $output . $this->displayForm();
    }

    public function hookDisplayLeftColumn($params)
    {
        $this->context->smarty->assign([
            'ns_page_name' => Configuration::get('MYMODULE_PAGENAME'),
            'ns_page_link' => $this->context->link->getModuleLink('mymodule', 'display')
          ]);

          return $this->display(__FILE__, 'mymodule.tpl');
    }

    public function displayForm() {
       $fields_form = array();
       $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
       $fields_form[0]['form'] = array(
           'legend' => array(
               'title' => $this->l('Settings the carousel'),
           ),
           'input' => array(
               array(
                   'type' => 'text',
                   'col' => 1,
                   'label' => $this->l('Speed'),
                   'name' => 'MYMODULE_SPEED',
                   'size' => 20,
                   'required' => false
               ),

               array(
                   'type' => 'text',
                   'col' => 1,
                   'label' => $this->l('Rows'),
                   'name' => 'MYMODULE_ROWS',
                   'size' => 20,
                   'required' => false
               ),
               array(
                   'type' => 'text',
                    'col' => 1,
                   'label' => $this->l('Products to show'),
                   'name' => 'MYMODULE_PRODUCT',
                   'size' => 20,
                   'required' => false
               )
           ),
           'submit' => array(
               'title' => $this->l('Save'),
               'class' => 'btn btn-default'
           )

       );

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;
        $helper->toolbar_scroll = true;
        $helper->submit_action = 'submit' . $this->name;
        $helper->toolbar_btn = array(
           'save' =>
               array(
                   'desc' => $this->l('Save'),
                   'href' => AdminController::$currentIndex . '&configure=' . $this->name . '&save' . $this->name .
                       '&token=' . Tools::getAdminTokenLite('AdminModules'),
               ),
           'back' => array(
               'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminModules'),
               'desc' => $this->l('Back to list')
           )
        );


        $helper->tpl_vars = array(
            'fields_value' => array(
                'MYMODULE_SPEED' => Configuration::get('MYMODULE_SPEED'),
                'MYMODULE_ROWS' => Configuration::get('MYMODULE_ROWS'),
                'MYMODULE_PRODUCT' => Configuration::get('MYMODULE_PRODUCT')
            ),
         );

         return $helper->generateForm($fields_form);
        }
}