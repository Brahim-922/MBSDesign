<?php
// file: controllers/front/something.php

class MymoduleSomethingModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        $this->title = $this->module->trans('My module title', [], 'Modules.Mymodule.Something');
    }
}