<?php
// file: mymodule.php

class mymodule extends Module
{
    public function __construct()
    {
        $this->displayName = $this->trans('My module', [], 'Modules.Mymodule.Mymodule');
        $this->description = $this->trans('Description of my module.', [], 'Modules.Mymodule.Mymodule');
    }
}
