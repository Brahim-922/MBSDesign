$(document).ready(function(){
 
    $('#owl-1').slick({
          rows: 2,
          dots: false,
          arrows: true,
          infinite: true,
          speed: parseInt(MYMODULE_SPEED),
          slidesToShow: 4,
          slidesToScroll: 6,
          autoplay: true,
          autoplaySpeed: 500,
          navSpeed: 500,
          autoplayTimeout: 2000,
          autoplayHoverPause: true,
  });
  
  
  })
  
  
  
  const showMenu = (toggleId, navId) =>{
      const toggle = document.getElementById(toggleId),
      nav = document.getElementById(navId)
  
      if(toggle && nav){
          toggle.addEventListener('click', ()=>{
              nav.classList.toggle('show')
          })
      }
  }
  showMenu('nav-tabs')
  
  
  const navLink = document.querySelectorAll('.nav__link');   
  
  function linkAction(){
    
    navLink.forEach(n => n.classList.remove('active'));
    this.classList.add('active');
    
    
    const navMenu = document.getElementById('nav-tabs')
    navMenu.classList.remove('show')
  }
  navLink.forEach(n => n.addEventListener('click', linkAction));

function jepostemavaleur(mavariable) {
    var xhr;
    if (window.XMLHttpRequest) {
    xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
    xhr = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
    throw new Error("Ajax is not supported by this browser");
    }
    xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
    if (xhr.status == 200 && xhr.status < 300) {
    document.getElementById('madiv').innerHTML = xhr.responseText;
    $('.your-class').slick({
    infinite:true,
    vertical:true,
    slidesToShow: 4,
    slidesToScroll: 1,
    initialSlide: mavariable
    });
    }
    }
    }
    alert(mavariable);//m'affiche bien l'id de l'élément posté
    xhr.open('POST', 'traitement.php');
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send();
    }